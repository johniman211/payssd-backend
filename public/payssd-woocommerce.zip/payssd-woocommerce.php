<?php
/**
 * Plugin Name: PaySSD for WooCommerce
 * Description: Accept mobile money payments via PaySSD using your merchant API key.
 * Version: 1.0
 * Author: PaySSD
 */

if (!defined('ABSPATH')) {
    exit;
}

// Register the gateway
add_filter('woocommerce_payment_gateways', 'payssd_add_gateway_class');
function payssd_add_gateway_class($gateways) {
    $gateways[] = 'WC_Gateway_PaySSD';
    return $gateways;
}

// Init the gateway class
add_action('plugins_loaded', 'payssd_init_gateway_class');
function payssd_init_gateway_class() {
    class WC_Gateway_PaySSD extends WC_Payment_Gateway {

        public function __construct() {
            $this->id = 'payssd';
            $this->icon = ''; // Optional icon URL
            $this->has_fields = false;
            $this->method_title = 'PaySSD';
            $this->method_description = 'Pay via PaySSD using your merchant API key.';

            $this->init_form_fields();
            $this->init_settings();

            $this->title = $this->get_option('title');
            $this->description = $this->get_option('description');
            $this->api_key = $this->get_option('api_key');

            add_action('woocommerce_update_options_payment_gateways_' . $this->id, array($this, 'process_admin_options'));
        }

        public function init_form_fields() {
            $this->form_fields = array(
                'enabled' => array(
                    'title' => 'Enable/Disable',
                    'type' => 'checkbox',
                    'label' => 'Enable PaySSD Payment',
                    'default' => 'yes'
                ),
                'title' => array(
                    'title' => 'Title',
                    'type' => 'text',
                    'description' => 'Displayed at checkout.',
                    'default' => 'Pay with PaySSD',
                    'desc_tip' => true,
                ),
                'description' => array(
                    'title' => 'Description',
                    'type' => 'textarea',
                    'description' => 'Displayed on the checkout page.',
                    'default' => 'Pay securely using mobile money through PaySSD.',
                ),
                'api_key' => array(
                    'title' => 'Merchant API Key',
                    'type' => 'text',
                    'description' => 'Enter your PaySSD merchant API key.',
                ),
            );
        }

        public function process_payment($order_id) {
            $order = wc_get_order($order_id);

            $response = wp_remote_post('http://localhost:5001/api/payment', array(
                'method'    => 'POST',
                'headers'   => array(
                    'Content-Type'  => 'application/json',
                    'x-api-key'     => $this->api_key,
                ),
                'body'      => json_encode(array(
                    'amount'        => $order->get_total(),
                    'currency'      => $order->get_currency(),
                    'reference'     => $order->get_order_key(),
                    'customer_name' => $order->get_billing_first_name() . ' ' . $order->get_billing_last_name(),
                    'customer_email'=> $order->get_billing_email(),
                    'customer_phone'=> $order->get_billing_phone(),
                )),
                'timeout' => 60,
            ));

            if (is_wp_error($response)) {
                wc_add_notice('Payment error: ' . $response->get_error_message(), 'error');
                return array('result' => 'fail');
            }

            $body = json_decode(wp_remote_retrieve_body($response), true);

            if (!empty($body['success'])) {
                $order->payment_complete();
                $order->add_order_note('PaySSD payment successful.');
                return array(
                    'result' => 'success',
                    'redirect' => $this->get_return_url($order),
                );
            } else {
                wc_add_notice('Payment failed: ' . ($body['message'] ?? 'Unknown error'), 'error');
                return array('result' => 'fail');
            }
        }
    }
}
