=== PaySSD for WooCommerce ===
Contributors: payssd
Tags: woocommerce, payment, payssd, mobile money
Requires at least: 5.0
Tested up to: 6.5
Stable tag: 1.0
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Accept secure mobile money payments with PaySSD inside WooCommerce.
